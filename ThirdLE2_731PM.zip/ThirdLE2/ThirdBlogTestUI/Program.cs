﻿using Microsoft.Extensions.Configuration;
using ThirdBlogDataLibrary.Data;
using ThirdBlogDataLibrary.Database;
using ThirdBlogDataLibrary.Models;

namespace ThirdBlogTestUI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            SqlData db = GetConnection();

            Authenticate(db);

            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();

            //No info where to place this call
            Register(db);

            Console.WriteLine("Registration Done - either success or fail.");

            Console.WriteLine("Press Enter to exit...");
            Console.ReadLine();
        }

        //FIRST METHOD
        static SqlData GetConnection()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            IConfiguration config = builder.Build();
            ISqlDataAccess dbAccess = new SqlDataAccess(config);
            SqlData db = new SqlData(dbAccess);

            return db;
        }

        //SECOND METHOD
        private static UserModel GetCurrentUser(SqlData db)
        {
            Console.Write("Username: ");
            string username = Console.ReadLine();

            Console.Write("Password: ");
            string password = Console.ReadLine();

            UserModel user = db.Authenticate(username, password);

            return user;
        }//end of second

        //THIRD METHOD
        private static void Authenticate(SqlData db)
        {
            //data of Get.. returns a user goes to user variable
            UserModel user = GetCurrentUser(db);

            if (user == null)
            {
                Console.WriteLine("Invalid credentials.");
            }
            else
            {
                Console.WriteLine($"Welcome, {user.UserName}");
            }
        }//end of third

        //FOURTH METHOD
        public static void Register(SqlData db)
        {
            Console.Write("Enter new username: ");
            var username = Console.ReadLine();

            Console.Write("Enter new password: ");
            var password = Console.ReadLine();

            Console.Write("Enter first name: ");
            var firstName = Console.ReadLine();

            Console.Write("Enter last name: ");
            var lastName = Console.ReadLine();

            db.Register(username, firstName, lastName, password);

            
        }
    }
}