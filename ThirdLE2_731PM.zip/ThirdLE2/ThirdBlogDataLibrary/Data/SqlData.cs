﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdBlogDataLibrary.Database;
using ThirdBlogDataLibrary.Models;

namespace ThirdBlogDataLibrary.Data
{
    public class SqlData
    {
        private ISqlDataAccess _db;
        private const string connectionStringName = "SqlDb";
        
        //CONSTRUCTOR
        public SqlData(ISqlDataAccess db)
        {
            _db = db;
        }

        //FIRST METHOD
        public UserModel Authenticate(string username, string password)
        { 
            UserModel result = _db.LoadData<UserModel, dynamic>("dbo.spUsers_Authenticate",
                                                                new { username, password},
                                                                connectionStringName,
                                                                true).FirstOrDefault();//FirstOrDefault() returns the first row of a set of results, or null.

            return result;
        }//end of method

        //SECOND METHOD
        public void Register(string username, string firstName, string lastName, string password)
        {
            _db.SaveData<dynamic>(
                "dbo.spUsers_Register",
                new { username, firstName, lastName, password },
                connectionStringName,
                true);
        }//end of method
    }
}

/*
 ISqlDataAccess is used as a parameter so that it accepts anything that implements the interface.
This lab exercise uses SQL Server, but if ever other SQL DBMS is used (eg. MySQL), there’s no
need to change this code as long as the MySQL class implements ISqlDataAccess.
 */
