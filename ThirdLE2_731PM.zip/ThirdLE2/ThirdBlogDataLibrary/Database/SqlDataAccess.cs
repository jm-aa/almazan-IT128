﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdBlogDataLibrary.Database
{
    public class SqlDataAccess : ISqlDataAccess
    {
        //FIRST METHOD
        private IConfiguration _config;
        public SqlDataAccess(IConfiguration config)
        {
            _config = config;
        }
        //_config contains the connection string to the database.
        // Passing it as a parameter rather than hardcoding it in
        // the program allows it to be easily modified and therefore have loosely coupled.

        //SECOND METHOD
        //as another method
        public List<T> LoadData<T, U>(string sqlStatement,
                                                U parameters,
                                                string connectionStringName,
                                                bool isStoredProcedure)
        {
            CommandType commandType = CommandType.Text;
            string connectionString = _config.GetConnectionString(connectionStringName);

            if (isStoredProcedure)
            {
                commandType = CommandType.StoredProcedure;
            }

            using (IDbConnection connection = new SqlConnection(connectionString))
            {
                List<T> rows = connection.Query<T>(sqlStatement, parameters,
                                                    commandType: commandType).ToList();
                return rows;
            }
        }

        /*
         Stored procedures are a set of SQL code. They are usually used for commands that are frequently
run, as the databased stores it tokenized in memory unlike queries, that has to be compiled every
time.
T, U are generics, which is a concept that is a replacement of a specific data type.
         */


        //THIRD METHOD
        //as another method
        public void SaveData<T>(string sqlStatement,
                                        T parameters,
                                        string connectionStringName,
                                        bool isStoredProcedure)
        {
            string connectionString = _config.GetConnectionString(connectionStringName);
            CommandType commandType = CommandType.Text;

            if (isStoredProcedure)
            {
                commandType = CommandType.StoredProcedure;
            }

            using (IDbConnection connection = new SqlConnection(connectionString))
            {
                connection.Execute(sqlStatement, parameters, commandType: commandType);
            }
        }
        //For SQL commands that save data into the database
    }
}
