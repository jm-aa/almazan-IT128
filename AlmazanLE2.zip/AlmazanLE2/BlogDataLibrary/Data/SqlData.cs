﻿using BlogDataLibrary.Database;

namespace BlogDataLibrary.Data
{
    internal class SqlData
    {
        private ISqlDataAccess _db;
        private const string connecyionStringName = "SqlDb";

        public SqlData(ISqlDataAccess db)
        {
            _db = db;
        }
    }
}
