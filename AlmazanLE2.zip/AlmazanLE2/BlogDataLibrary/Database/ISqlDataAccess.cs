﻿//manual interface

namespace BlogDataLibrary.Database//not BlogDataLibrary.Database.ISqlDataAccess
{
    public interface ISqlDataAccess//"public" from "internal"
    {
        //no constructor, no "public"
        List<T> LoadData<T, U>(string sqlStatement,
                                U parameters,
                                string connectionStringName,
                                bool isStoredProcedure);
        void SaveData<T>(string sqlStatement,
                            T parameters,
                            string connectionStringName,
                            bool isStoredProcedure);
    }
}
